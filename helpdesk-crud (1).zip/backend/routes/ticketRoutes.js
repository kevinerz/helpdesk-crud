const express = require("express");
const Ticket = require("../models/Ticket");
const router = express.Router();

// Get all tickets
router.get("/", async (req, res) => {
  try {
    const tickets = await Ticket.find();
    res.json(tickets);
  } catch (error) {
    res.status(500).json({ error: "Error fetching tickets" });
  }
});

// Create new ticket
router.post("/", async (req, res) => {
  try {
    const newTicket = new Ticket(req.body);
    await newTicket.save();
    res.json(newTicket);
  } catch (error) {
    res.status(500).json({ error: "Error creating ticket" });
  }
});

module.exports = router;
