const mongoose = require("mongoose");
const TicketSchema = new mongoose.Schema({
  title: String,
  status: { type: String, default: "Open" },
}, { timestamps: true });
module.exports = mongoose.model("Ticket", TicketSchema);
